﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace MathGame.Client
{
    public partial class Instructions : Form
    {
        public Instructions()
        {
            InitializeComponent();
        }
    }
}
